package ru.matrux.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.res.imageResource
import ru.matrux.app.R
import ru.matrux.app.ui.theme.Matrux

private const val PATTERN_ALPHA = 0.22f

@Composable
fun AppBackdrop(modifier: Modifier = Modifier) {
    val colors = Matrux.colors
    val tile = ImageBitmap.imageResource(R.drawable.pattern_circuit)
    val pattern = remember(tile) {
        ShaderBrush(ImageShader(tile, TileMode.Repeated, TileMode.Repeated))
    }
    val alpha = if (colors.canvas.luminance() < 0.4f) 0.05f else PATTERN_ALPHA
    Canvas(modifier.fillMaxSize()) {
        drawRect(brush = pattern, alpha = alpha)
        drawRect(
            brush = Brush.verticalGradient(
                0f to colors.canvas.copy(alpha = 0f),
                0.42f to colors.canvas.copy(alpha = 0.30f),
                0.72f to colors.canvas.copy(alpha = 0.85f),
                1f to colors.canvas,
            ),
        )
    }
}
